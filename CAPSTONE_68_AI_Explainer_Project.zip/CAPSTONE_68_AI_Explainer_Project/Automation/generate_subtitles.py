"""
CAPSTONE 68 – Script-to-SRT subtitle starter
Creates approximate subtitle timestamps based on word count.
IMPORTANT: This does NOT listen to audio. Always adjust timings against the final narration.
Usage: python generate_subtitles.py script.txt captions.srt --duration 120
"""
import argparse
import re
from pathlib import Path

def to_srt_time(seconds: float) -> str:
    milliseconds = round(seconds * 1000)
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{millis:03}"

def split_sentences(text: str):
    text = re.sub(r"\s+", " ", text).strip()
    return [part.strip() for part in re.split(r"(?<=[.!?])\s+", text) if part.strip()]

def generate_srt(script: str, duration: float) -> str:
    sentences = split_sentences(script)
    if not sentences:
        raise ValueError("The script is empty.")
    weights = [max(1, len(re.findall(r"\b[\w'-]+\b", sentence))) for sentence in sentences]
    total_weight = sum(weights)
    current = 0.0
    blocks = []
    for index, (sentence, weight) in enumerate(zip(sentences, weights), start=1):
        segment = duration * weight / total_weight
        start = current
        end = current + segment
        current = end
        blocks.append(
            f"{index}\n{to_srt_time(start)} --> {to_srt_time(end)}\n{sentence}"
        )
    return "\n\n".join(blocks) + "\n"

def main():
    parser = argparse.ArgumentParser(description="Generate approximate SRT captions from a script.")
    parser.add_argument("input", help="Path to UTF-8 text script")
    parser.add_argument("output", help="Output .srt file")
    parser.add_argument("--duration", type=float, default=120.0, help="Estimated audio duration in seconds")
    args = parser.parse_args()
    if args.duration <= 0:
        parser.error("--duration must be greater than zero")
    script = Path(args.input).read_text(encoding="utf-8")
    srt = generate_srt(script, args.duration)
    Path(args.output).write_text(srt, encoding="utf-8")
    print(f"Created {args.output}. Review all timings against the final audio.")

if __name__ == "__main__":
    main()
