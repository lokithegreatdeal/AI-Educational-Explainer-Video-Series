SUBTITLE AUTOMATION
1. Copy the narration text into script.txt (remove slide headings if you do not want them spoken).
2. Open a terminal in this folder.
3. Run: python generate_subtitles.py script.txt captions.srt --duration 120
4. Import captions.srt into your video editor.
5. Manually correct every caption timing against the actual voice recording.

This is a word-count-based estimate, not automatic speech recognition. Actual pauses and speaking speed vary.
