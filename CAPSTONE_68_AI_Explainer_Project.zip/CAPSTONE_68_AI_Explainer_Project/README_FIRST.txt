CAPSTONE 68 – START HERE

This ZIP is a complete project starter package containing:
- Research report (DOCX) and source register
- Three expanded educational scripts
- Video accuracy checklist
- Five-slide PowerPoint deck
- Viewer feedback form and Excel analysis template
- Ten-question quiz and answer key
- Python script-to-SRT automation
- Prompt library
- AI verification test template
- Video/audio production instructions

IMPORTANT:
1. The three final MP4 avatar videos are not pre-rendered. They require external avatar/voice tools and your own account/export.
2. Viewer feedback and verification results are blank templates. Collect real feedback and perform real tests; never fabricate results.
3. Free tool plans and features change. Confirm current quotas, export limits, watermark rules and terms on official help pages.
4. Subtitle timestamps are estimated from word counts and must be manually synchronized to the final audio.
5. Use only voices/avatars you have permission to use and label synthetic media clearly.

Suggested order:
Research -> scripts -> accuracy review -> voice/avatar -> slides/editing -> subtitles -> viewer testing -> final report/demo.
