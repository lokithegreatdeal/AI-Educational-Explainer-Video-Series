VIDEO OUTPUTS TO CREATE
Video_01_ML_Introduction.mp4
Video_02_ML_Workflow.mp4
Video_03_ML_Types.mp4

The ZIP contains scripts and production instructions, not finished rendered avatar videos. Create them using the accounts/tools available to you. Free-tier quotas, export restrictions and watermarks can change. If avatar quota is insufficient, use synthetic narration over slides and disclose the AI-generated voice.
